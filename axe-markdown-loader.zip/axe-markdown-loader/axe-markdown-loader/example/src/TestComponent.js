import React from 'react';

const TestComponent = ({someProp}) => (
	<div>
		A test component

		<br /><br />
		someProp = "{someProp}"
	</div>
);

export default TestComponent;