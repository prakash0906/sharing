---
title: Three dashes marks the spot
tags:
  - yaml
  - front-matter
  - dashes
expaned-description: with some --- crazy stuff in it
---

don't break

---

Also this shouldn't be a problem
