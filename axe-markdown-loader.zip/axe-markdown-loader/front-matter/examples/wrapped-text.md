---
title: Complex yaml example
description: You can use the front-matter module to convert this
tags: [example, yaml, node]
folded-text: |
  There once was a man from Darjeeling
  Who got on a bus bound for Ealing
      It said on the door
      "Please don't spit on the floor"
  So he carefully spat on the ceiling
wrapped-text: >
  Wrapped text
  will be folded
  into a single
  paragraph

  Blank lines denote
  paragraph breaks
---

Some crazy stuff going on up there ^^
