= yaml =
title: I couldn't think of a better name
description: Just an example of using `= yaml =`
= yaml =

Plays nice with markdown syntax highlighting
